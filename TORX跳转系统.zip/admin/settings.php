<?php
session_start();
define('SECURE_ACCESS', true);

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$config_file = '../config/config.php';
$config = include $config_file;
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: login.php');
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content_type = $_POST['content_type'] ?? 'text';
    $config['content_type'] = $content_type;
    
    if ($content_type === 'text') {
        $config['text_content'] = $_POST['text_content'] ?? '';
    }
    
    if ($content_type === 'image') {
        $image_type = $_POST['image_type'] ?? 'upload';
        $config['image_type'] = $image_type;
        
        if ($image_type === 'url') {
            $config['image_url'] = $_POST['image_url'] ?? '';
        } else {
            if (isset($_FILES['image_upload']) && $_FILES['image_upload']['error'] === 0) {
                $upload_dir = '../uploads/';
                $file_name = basename($_FILES['image_upload']['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($file_ext, $allowed_types)) {
                    $new_file_name = 'image_' . time() . '.' . $file_ext;
                    $upload_path = $upload_dir . $new_file_name;
                    
                    if (move_uploaded_file($_FILES['image_upload']['tmp_name'], $upload_path)) {
                        if (!empty($config['image_path']) && file_exists('../' . $config['image_path'])) {
                            @unlink('../' . $config['image_path']);
                        }
                        $config['image_path'] = 'uploads/' . $new_file_name;
                    } else {
                        $message = '图片上传失败，请重试';
                    }
                } else {
                    $message = '只允许上传 JPG, JPEG, PNG 或 GIF 格式的图片';
                }
            }
        }
    }
    
    if ($content_type === 'redirect') {
        $config['redirect_url'] = $_POST['redirect_url'] ?? '';
    }
    
    $config['last_updated'] = date('Y-m-d H:i:s');
    
    if (empty($message)) {
        $config_content = "<?php\nif (!defined('SECURE_ACCESS')) {\n    header('HTTP/1.0 403 Forbidden');\n    exit;\n}\nreturn " . var_export($config, true) . ";\n?>";
        
        if (file_put_contents($config_file, $config_content)) {
            $message = '设置已成功保存';
        } else {
            $message = '保存设置失败，请检查文件权限';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>内容设置 - 管理后台</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #a3bffa 0%, #7f9cf5 50%, #667eea 100%);
            --card-bg: rgba(255, 255, 255, 0.95);
            --shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            --text-color: #2d3748;
            --input-border: rgba(160, 174, 192, 0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Noto Sans SC', 'Segoe UI', system-ui, sans-serif;
            background: var(--primary-gradient);
            color: var(--text-color);
            min-height: 100vh;
        }

        header {
            background: var(--card-bg);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            backdrop-filter: blur(8px);
        }

        header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logout {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            padding: 0.5rem 1rem;
            border-radius: 0.75rem;
            text-decoration: none;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout:hover {
            background: rgba(239, 68, 68, 0.2);
            transform: translateY(-1px);
        }

        .container {
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .menu {
            display: flex;
            gap: 1rem;
            margin: 2rem 0;
        }

        .menu a {
            background: rgba(127, 156, 245, 0.1);
            color: #4a5568;
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            text-decoration: none;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .menu a.active {
            background: #667eea;
            color: white;
        }

        .menu a:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        /* 统一欢迎卡片容器样式 */
.card.welcome {
    background: var(--card-bg);
    border-radius: 1.5rem;
    padding: 1.5rem;
    box-shadow: var(--shadow);
    margin: 0 0 2rem 0; /* 与首页完全相同的间距设置 */
    transition: transform 0.3s ease;
}

/* 统一标题样式 */
.card.welcome h2 {
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    font-size: 1.25rem;
    color: var(--text-color); /* 继承主文本颜色 */
}

/* 统一段落样式 */
.card.welcome p {
    color: #718096;
    line-height: 1.6;
    font-size: 0.95rem;
    margin: 0; /* 移除默认段落间距 */
}

        .settings-card {
            background: var(--card-bg);
            border-radius: 1.5rem;
            padding: 2rem;
            box-shadow: var(--shadow);
            margin: 1.5rem 0;
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
        }

        .settings-card:hover {
            transform: translateY(-5px);
        }

        .message {
            padding: 1.25rem;
            border-radius: 1rem;
            margin: 1.5rem 0;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .message.success {
            background: rgba(167, 243, 208, 0.9);
            color: #065f46;
        }

        .message.error {
            background: rgba(254, 202, 202, 0.9);
            color: #991b1b;
        }

        .radio-group {
            display: flex;
            gap: 1.5rem;
            margin: 1rem 0;
        }

        input[type="radio"] {
            display: none;
        }

        input[type="radio"] + label {
            background: rgba(127, 156, 245, 0.1);
            padding: 1rem 1.5rem;
            border-radius: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        input[type="radio"]:checked + label {
            background: #667eea;
            color: white;
        }

        textarea {
            width: 100%;
            padding: 1rem;
            border: 2px solid var(--input-border);
            border-radius: 1rem;
            min-height: 150px;
            resize: vertical;
            font-family: inherit;
            color: inherit;
        }

        input[type="url"],
        input[type="file"] {
            width: 100%;
            padding: 0.9rem;
            border: 2px solid var(--input-border);
            border-radius: 0.75rem;
            font-family: inherit;
            color: inherit;
        }

        .preview-image {
            max-width: 300px;
            height: auto;
            border-radius: 1rem;
            margin-top: 1rem;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        button[type="submit"] {
            background: linear-gradient(135deg, #667eea 0%, #7f9cf5 100%);
            color: white;
            padding: 1rem 2rem;
            border: none;
            border-radius: 0.75rem;
            font-size: 1.1rem;
            cursor: pointer;
            transition: transform 0.2s ease;
            width: 100%;
            margin-top: 1.5rem;
            font-family: inherit;
        }

        button[type="submit"]:hover {
            transform: translateY(-2px);
        }

        .last-updated {
            text-align: center;
            color: #718096;
            margin-top: 2rem;
            padding: 1rem;
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: var(--shadow);
        }

        @media (max-width: 768px) {
            header {
                padding: 1rem;
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .radio-group {
                flex-direction: column;
            }
            
            .container {
                padding: 1rem;
            }
            
            .menu {
                flex-wrap: wrap;
            }
            
            .preview-image {
                max-width: 100%;
            }
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var contentTypeRadios = document.querySelectorAll('input[name="content_type"]');
            var imageTypeRadios = document.querySelectorAll('input[name="image_type"]');
            
            contentTypeRadios.forEach(function(radio) {
                radio.addEventListener('change', function() {
                    document.querySelectorAll('.content-section').forEach(function(section) {
                        section.style.display = 'none';
                    });
                    var selectedSection = document.getElementById(this.value + '-section');
                    if (selectedSection) selectedSection.style.display = 'block';
                });
            });
            
            imageTypeRadios.forEach(function(radio) {
                radio.addEventListener('change', function() {
                    document.querySelectorAll('.image-type-section').forEach(function(section) {
                        section.style.display = 'none';
                    });
                    var selectedSection = document.getElementById(this.value + '-section');
                    if (selectedSection) selectedSection.style.display = 'block';
                });
            });
            
            var currentContentType = '<?php echo $config['content_type']; ?>';
            var currentContentRadio = document.querySelector('input[name="content_type"][value="' + currentContentType + '"]');
            if (currentContentRadio) currentContentRadio.dispatchEvent(new Event('change'));
            
            var currentImageType = '<?php echo $config['image_type']; ?>';
            var currentImageRadio = document.querySelector('input[name="image_type"][value="' + currentImageType + '"]');
            if (currentImageRadio) currentImageRadio.dispatchEvent(new Event('change'));
            
            document.getElementById('image_url').addEventListener('input', function() {
                var previewImg = document.getElementById('preview-image');
                previewImg.src = this.value;
                previewImg.style.display = this.value ? 'block' : 'none';
            });
            
            document.getElementById('image_upload').addEventListener('change', function() {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('upload-preview-image').src = e.target.result;
                        document.getElementById('upload-preview-image').style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
</head>
<body>
    <header>
        <h1><i class="fas fa-cogs"></i> 网站管理后台</h1>
        <a href="?action=logout" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            退出登录
        </a>
    </header>
    
    <div class="container">
        <div class="card welcome">
            <h2><i class="fas fa-door-open"></i> 欢迎回来</h2>
            <p>在这里您可以管理网站前台显示的内容。请点击下方的导航按钮进行操作。</p>
        </div>

        <div class="menu">
            <a href="index.php"><i class="fas fa-home"></i> 首页</a>
            <a href="settings.php" class="active"><i class="fas fa-cog"></i> 内容设置</a>
        </div>

        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, '失败') !== false ? 'error' : 'success'; ?>">
                <i class="fas <?php echo strpos($message, '失败') !== false ? 'fa-exclamation-circle' : 'fa-check-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="settings-card">
            <h3><i class="fas fa-paint-brush"></i> 内容设置</h3><br>
            <p style="color: #718096; margin-bottom: 1.5rem;">请选择您想要在前台显示的内容类型，并进行相应设置。</p>

            <form method="post" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label>内容类型</label>
                    <div class="radio-group">
                        <input type="radio" id="type-text" name="content_type" value="text" <?php echo $config['content_type'] === 'text' ? 'checked' : ''; ?>>
                        <label for="type-text"><i class="fas fa-align-left"></i> 文本内容</label>
                        
                        <input type="radio" id="type-image" name="content_type" value="image" <?php echo $config['content_type'] === 'image' ? 'checked' : ''; ?>>
                        <label for="type-image"><i class="fas fa-image"></i> 图片展示</label>
                        
                        <input type="radio" id="type-redirect" name="content_type" value="redirect" <?php echo $config['content_type'] === 'redirect' ? 'checked' : ''; ?>>
                        <label for="type-redirect"><i class="fas fa-external-link-alt"></i> 链接跳转</label>
                    </div>
                </div>

                <div id="text-section" class="content-section">
                    <div class="form-group">
                        <label for="text_content"><i class="fas fa-edit"></i> 文本内容</label>
                        <textarea id="text_content" name="text_content"><?php echo htmlspecialchars($config['text_content']); ?></textarea>
                    </div>
                </div>

                <div id="image-section" class="content-section">
                    <div class="form-group">
                        <label><i class="fas fa-camera"></i> 图片来源</label>
                        <div class="radio-group">
                            <input type="radio" id="image-upload" name="image_type" value="upload" <?php echo $config['image_type'] === 'upload' ? 'checked' : ''; ?>>
                            <label for="image-upload"><i class="fas fa-upload"></i> 上传图片</label>
                            
                            <input type="radio" id="image-url" name="image_type" value="url" <?php echo $config['image_type'] === 'url' ? 'checked' : ''; ?>>
                            <label for="image-url"><i class="fas fa-link"></i> 外部链接</label>
                        </div>
                    </div>

                    <div id="upload-section" class="image-type-section">
                        <div class="form-group">
                            <label for="image_upload"><i class="fas fa-folder-open"></i> 选择图片</label>
                            <input type="file" id="image_upload" name="image_upload" accept="image/*">
                            <?php if (!empty($config['image_path']) && $config['image_type'] === 'upload'): ?>
                                <img src="../<?php echo htmlspecialchars($config['image_path']); ?>" alt="当前图片" class="preview-image">
                            <?php endif; ?>
                            <img id="upload-preview-image" class="preview-image" style="display: none;" alt="预览图片">
                        </div>
                    </div>

                    <div id="url-section" class="image-type-section">
                        <div class="form-group">
                            <label for="image_url"><i class="fas fa-globe"></i> 图片URL</label>
                            <input type="url" id="image_url" name="image_url" value="<?php echo htmlspecialchars($config['image_url']); ?>" placeholder="https://example.com/image.jpg">
                            <?php if (!empty($config['image_url']) && $config['image_type'] === 'url'): ?>
                                <img id="preview-image" src="<?php echo htmlspecialchars($config['image_url']); ?>" alt="预览图片" class="preview-image">
                            <?php else: ?>
                                <img id="preview-image" class="preview-image" style="display: none;" alt="预览图片">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div id="redirect-section" class="content-section">
                    <div class="form-group">
                        <label for="redirect_url"><i class="fas fa-external-link-square-alt"></i> 跳转URL</label>
                        <input type="url" id="redirect_url" name="redirect_url" value="<?php echo htmlspecialchars($config['redirect_url']); ?>" placeholder="https://example.com">
                    </div>
                </div>

                <button type="submit"><i class="fas fa-save"></i> 保存设置</button>
            </form>
        </div>

        <div class="last-updated">
            <i class="fas fa-clock"></i> 最后更新：<?php echo $config['last_updated']; ?>
        </div>
    </div>
</body>
</html>