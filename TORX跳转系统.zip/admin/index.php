<?php
session_start();
define('SECURE_ACCESS', true);

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$config_file = '../config/config.php';
$config = include $config_file;

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #a3bffa 0%, #7f9cf5 50%, #667eea 100%);
            --card-bg: rgba(255, 255, 255, 0.95);
            --shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
            --text-color: #2d3748;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Noto Sans SC', 'Segoe UI', system-ui, sans-serif;
            background: var(--primary-gradient);
            color: var(--text-color);
            min-height: 100vh;
        }

        header {
            background: var(--card-bg);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            backdrop-filter: blur(8px);
        }

        header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logout {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            padding: 0.5rem 1rem;
            border-radius: 0.75rem;
            text-decoration: none;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout:hover {
            background: rgba(239, 68, 68, 0.2);
            transform: translateY(-1px);
        }

        .container {
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        /* 修复卡片透明问题的核心修改 */
        .card {
            background: var(--card-bg);
            border-radius: 1.5rem;
            padding: 1.5rem;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card.welcome {
            margin: 0 0 2rem 0;
        }

        .card.welcome h2 {
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.25rem;
            color: var(--text-color);
        }

        .card.welcome p {
            color: #718096;
            line-height: 1.6;
            font-size: 0.95rem;
            margin: 0;
        }

        .menu {
            display: flex;
            gap: 1rem;
            margin: 2rem 0;
        }

        .menu a {
            background: rgba(127, 156, 245, 0.1);
            color: #4a5568;
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            text-decoration: none;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .menu a.active {
            background: #667eea;
            color: white;
        }

        .menu a:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .status-badge {
            background: rgba(127, 156, 245, 0.1);
            color: #667eea;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.9rem;
        }

        .last-updated {
            text-align: center;
            color: #718096;
            margin-top: 2rem;
            padding: 1rem;
            background: var(--card-bg);
            border-radius: 1rem;
        }

        h2, h3 {
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            header {
                padding: 1rem;
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1><i class="fas fa-cogs"></i> 网站管理后台</h1>
        <a href="?action=logout" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            退出登录
        </a>
    </header>
    
    <div class="container">
        <div class="card welcome">
            <h2><i class="fas fa-door-open"></i> 欢迎回来</h2>
            <p>在这里您可以管理网站前台显示的内容。请点击下方的导航按钮进行操作。</p>
        </div>

        <div class="menu">
            <a href="index.php" class="active"><i class="fas fa-home"></i> 首页</a>
            <a href="settings.php"><i class="fas fa-cog"></i> 内容设置</a>
        </div>

        <div class="dashboard-grid">
            <div class="card">
                <h3><i class="fas fa-info-circle"></i> 当前状态</h3>
                <p><strong>内容类型：</strong> 
                    <span class="status-badge">
                    <?php 
                    switch($config['content_type']) {
                        case 'text': echo '文本内容'; break;
                        case 'image': echo '图片显示'; break;
                        case 'redirect': echo '链接跳转'; break;
                        default: echo '未设置';
                    }
                    ?>
                    </span>
                </p>
            </div>

            <?php if($config['content_type'] === 'text'): ?>
            <div class="card">
                <h3><i class="fas fa-text-width"></i> 文本预览</h3>
                <p><?php echo htmlspecialchars(substr($config['text_content'], 0, 100)) . 
                    (strlen($config['text_content']) > 100 ? '...' : ''); ?></p>
            </div>
            <?php elseif($config['content_type'] === 'image'): ?>
            <div class="card">
                <h3><i class="fas fa-image"></i> 图片来源</h3>
                <p><?php echo $config['image_type'] === 'upload' ? '本地文件' : '外部链接'; ?></p>
            </div>
            <?php elseif($config['content_type'] === 'redirect'): ?>
            <div class="card">
                <h3><i class="fas fa-external-link-alt"></i> 跳转目标</h3>
                <p><?php echo htmlspecialchars($config['redirect_url']); ?></p>
            </div>
            <?php endif; ?>
        </div>

        <div class="last-updated">
            <i class="fas fa-clock"></i> 最后更新：<?php echo $config['last_updated']; ?>
        </div>
    </div>
</body>
</html>