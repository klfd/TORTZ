<?php
define('SECURE_ACCESS', true);

// 加载配置
$config = include 'config/config.php';

// 处理跳转链接
if ($config['content_type'] === 'redirect' && !empty($config['redirect_url'])) {
    header('Location: ' . $config['redirect_url']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>欢迎访问</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #a3bffa 0%, #7f9cf5 50%, #667eea 100%);
            --text-color: #2d3748;
            --card-bg: rgba(255, 255, 255, 0.95);
            --shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Noto Sans SC', 'Segoe UI', system-ui, sans-serif;
            line-height: 1.8;
            color: var(--text-color);
            background: var(--primary-gradient);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            padding: 2rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.6s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .content-card {
            background: var(--card-bg);
            border-radius: 1.5rem;
            box-shadow: var(--shadow);
            padding: 3rem;
            max-width: 800px;
            width: 90%;
            margin: 1rem;
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .content-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 12px 40px rgba(31, 38, 135, 0.2);
        }

        .text-content {
            font-size: 1.25rem;
            line-height: 1.8;
            text-align: center;
            letter-spacing: 0.5px;
            font-weight: 500;
            color: #4a5568;
        }

        .image-content {
            display: flex;
            justify-content: center;
            margin: 2rem 0;
        }

        .image-content img {
            max-width: 100%;
            height: auto;
            border-radius: 1rem;
            box-shadow: var(--shadow);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        footer {
            padding: 1.2rem;
            text-align: center;
            margin-top: auto;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(8px);
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
            letter-spacing: 0.5px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        footer p {
            margin: 0.3rem 0;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .content-card {
                padding: 2rem;
                width: 95%;
            }
            
            .text-content {
                font-size: 1.1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($config['content_type'] === 'text'): ?>
            <div class="content-card">
                <div class="text-content">
                    <?php echo nl2br(htmlspecialchars($config['text_content'])); ?>
                </div>
            </div>
        <?php elseif ($config['content_type'] === 'image'): ?>
            <div class="content-card">
                <div class="image-content">
                    <?php if ($config['image_type'] === 'upload' && !empty($config['image_path'])): ?>
                        <img src="<?php echo htmlspecialchars($config['image_path']); ?>" 
                             alt="显示图片"
                             loading="lazy">
                    <?php elseif ($config['image_type'] === 'url' && !empty($config['image_url'])): ?>
                        <img src="<?php echo htmlspecialchars($config['image_url']); ?>" 
                             alt="显示图片"
                             loading="lazy">
                    <?php else: ?>
                        <div class="text-content">
                            <i class="fas fa-image fa-3x mb-3" style="color: #c3dafe;"></i>
                            <p>未设置图片内容</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <footer>
        <p>&copy; 2025 Tor X 版权所有</p>
    </footer>
</body>
</html>