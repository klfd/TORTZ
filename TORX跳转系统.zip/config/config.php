<?php
// 防止直接访问配置文件
if (!defined('SECURE_ACCESS')) {
    header('HTTP/1.0 403 Forbidden');
    exit('禁止直接访问');
}

// 配置文件
return [
    // 管理员密码 (默认密码: admin123)
    'admin_password' => '0192023a7bbd73250516f069df18b500', // md5('admin123')
    
    // 前台显示内容
    'content_type' => 'text', // 可选: text, image, redirect
    
    // 文本内容
    'text_content' => '欢迎访问Tor X跳转系统！这是默认文本内容，请在管理后台修改。项目地址：https://github.com/klfd',
    
    // 图片设置
    'image_type' => 'upload', // 可选: upload, url
    'image_path' => '', // 上传图片的路径
    'image_url' => '', // 外部图片URL
    
    // 跳转链接
    'redirect_url' => '',
    
    // 最后更新时间
    'last_updated' => date('Y-m-d H:i:s')
];
?>
